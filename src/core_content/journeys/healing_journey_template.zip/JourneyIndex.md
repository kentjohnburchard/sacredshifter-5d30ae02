| Filename | Title | Tags | Veil Locked? |
|----------|-------|------|--------------|
| healing_journey_template.md | Healing Journey Template |  | No |
| JourneyIndex.md | JourneyIndex |  | No |
| journey_akashic_reconnection.md | Akashic Reconnection |  | No |
| journey_causal_body_clearing.md | Causal Body Clearing |  | No |
| journey_celestial_alignment_initiation.md | Celestial Alignment Initiation |  | No |
| journey_chakra_column_alignment.md | Chakra Column Alignment |  | No |
| journey_cosmic_womb_return.md | Cosmic Womb Return |  | No |
| journey_dna_recalibration.md | Dna Recalibration |  | No |
| journey_dna_recoding_activation.md | Dna Recoding Activation |  | No |
| journey_earth_start_activation.md | Earth Start Activation |  | No |
| journey_emotional_field_reset.md | Emotional Field Reset |  | No |
| journey_heart_activation.md | Heart Activation |  | No |
| journey_infinite_self_alignment.md | Infinite Self Alignment |  | No |
| journey_inner_child_resonance.md | Inner Child Resonance |  | No |
| journey_lightbody_activation.md | Lightbody Activation |  | No |
| journey_resonant_breathwork_expansion.md | Resonant Breathwork Expansion |  | No |
| journey_resonant_field_expansion.md | Resonant Field Expansion |  | No |
| journey_root_stabilization.md | Root Stabilization |  | No |
| journey_sacred_self_reclamation.md | Sacred Self Reclamation |  | No |
| journey_solar_activation.md | Solar Activation |  | No |
| journey_soul_contract_release.md | Soul Contract Release |  | No |
| journey_sound_current_alignment.md | Sound Current Alignment |  | No |
| journey_third_eye_activation.md | Third Eye Activation |  | No |
| journey_thymus_gate_activation.md | Thymus Gate Activation |  | No |
| journey_timeline_recalibration.md | Timeline Recalibration |  | No |
| journey_veil_lifting_initiation.md | Veil Lifting Initiation |  | No |
| journey_zero_point_stabilization.md | Zero Point Stabilization |  | No |
